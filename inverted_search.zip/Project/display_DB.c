#include "invertedIndex.h"

/*fucntion to display the database*/
int display_DB(wlist_t **head)
{
    /*loop to check if array of pointers have words*/
	for (int i = 0; i <= 25 ; i++)
	{
		int flag = 1;
		wlist_t *tmp = head[i];
		
		/*loop to traverse the list*/
		while (tmp != NULL)
		{
		    /*pattern to print index*/
			(flag-- == 1) ? printf(BLU "[%d]" C_RESET, i): printf(" ");
			
			file_table_t *temp = tmp -> t_link;
			
			/*pattern to printf the words and info*/
			printf(GRN "\t[%s]\t" C_RESET RED " %d" C_RESET "  file(s)", tmp ->  word, tmp -> f_count);
			
			/* loop to traverse every letter node to get related words*/
			while (temp != NULL)
			{
				printf("  : File : " GRN "%s" C_RESET " : " RED "%d" C_RESET " time(s)", temp -> f_name, temp -> w_count);
				temp = temp -> link;
			}
			printf(" -> NULL\n");
			tmp = tmp -> link;
		}
	}
}
